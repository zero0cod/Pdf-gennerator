// types.ts

// --------------------------------------------------
// 🧩 Base component properties shared across all types
// --------------------------------------------------


declare module "jspdf" {
  interface jsPDF {
    getNumberOfPages(): number;
  }
}
export interface BaseComponent {
  fontSize?: number;
  align?: 'left' | 'center' | 'right';
  spacing?: number;
  height?: number;
  color?: number[];
  width?: number;
  theme?: string;
  headerColor?: number[];
}

// --------------------------------------------------
// 📘 Specialized component extensions
// --------------------------------------------------

// 🔹 Title Component
export interface TitleComponent extends BaseComponent {
  type: 'title';
  text: string; 
}

// 🔹 Heading Component
export interface HeadingComponent extends BaseComponent {
  type: 'heading';
  text: string;
  level?: 1 | 2 | 3 | 4;
}

// 🔹 Paragraph Component
export interface ParagraphComponent extends BaseComponent {
  type: 'paragraph';
  text: string;
}

// 🔹 Space Component
export interface SpaceComponent extends BaseComponent {
  type: 'space';
  height?: number;
}

// 🔹 Line Component
export interface LineComponent extends BaseComponent {
  type: 'line';
  width?: number;
  color?: number[];
}

// 🔹 List Component
export interface ListComponent extends BaseComponent {
  type: 'list';
  listType?: 'bullet' | 'number';
  items?: string[];
  itemSpacing?: number;
}

// 🔹 Table Component
export interface TableComponent extends BaseComponent {
  type: 'table';
  headers?: string[];
  data?: any[][];
  theme?: 'striped' | 'grid' | 'plain';
}
export interface HeaderItem {
  type: "text" | "image";
  text?: string;
  src?: string;           // image URL/base64
  x?: number;             // x position (optional)
  y?: number;             // y position (optional)
  width?: number;
  height?: number;
  fontSize?: number;
  bold?: boolean;
  align?: "left" | "center" | "right";
}

export interface PageHeaderComponent extends BaseComponent {
  type: "pageHeader";
  items: HeaderItem[];     // array of header elements
  height?: number;         // default height for header band
  yOffset?: number;
  pageNumber?: number;
  pageNumbers?: number[];
  backgroundColor?: [number, number, number];
}
// --------------------------------------------------
// 🔗 Unified Type (Discriminated Union)
// --------------------------------------------------
export type ComponentProps =
  | TitleComponent
  | HeadingComponent
  | ParagraphComponent
  | SpaceComponent
  | LineComponent
  | ListComponent
  | TableComponent
  |PageHeaderComponent;
  // Img type need to be added
  // text type need to be added

// --------------------------------------------------
// Generator Option Types
// --------------------------------------------------
export interface GenerateOptions {
  addPageNumbers?: boolean;
  onProgress?: (progress: number) => void;
}
