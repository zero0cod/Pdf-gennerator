import { useState, type SetStateAction } from "react";
import { Eye, Download, FileText, Loader2 } from "lucide-react";
import type { ComponentProps } from "./types";
import { PDFGenerator } from "./pdfGeneratorUtility";

 const sampleData : ComponentProps[]= [
     {
    type: "pageHeader",
    items: [
      {
        type: "image",
        src: "https://example.com/metquay-logo.png",
        x: 15,
        y: 12,
        width: 20,
        height: 15,
      },
      {
        type: "text",
        text: "Metquay",
        align: "center",
        y: 10,
        fontSize: 12,
        bold: true,
      },
      {
        type: "text",
        text: "Building No: 5421, Old Street\nAustin, Texas, USA 956585\nPh: +17186520848",
        y: 16,
        align: "center",
        fontSize: 9,
      },
      {
        type: "image",
        src: "https://example.com/sac-singlas-logo.png",
        x: 170,
        y: 12,
        width: 25,
        height: 15,
      },
      {
        type: "text",
        text: "CERTIFICATE OF CALIBRATION",
        align: "center",
        y: 35,
        fontSize: 14,
        bold: true,
      },
      {
        type: "text",
        text: "Certificate No: UAL/000087/25",
        align: "center",
        y: 40,
        fontSize: 10,
      },
    ],
    backgroundColor: [255, 255, 255],
    pageNumbers: [1, 2, 3],
  },
    {
      type: 'space',
      height: 10
    },
    {
      type: 'heading',
      text: 'Executive Summary',
      level: 1
    },
    {
      type: 'paragraph',
      text: 'This report provides a comprehensive overview of our company performance throughout 2024. We have achieved significant milestones in revenue growth, customer acquisition, and market expansion. Our strategic initiatives have positioned us well for continued success in the coming years.',
      fontSize: 12
    },
    {
      type: 'space',
      height: 10
    },
    {
      type: 'heading',
      text: 'Key Metrics',
      level: 1
    },
    {
      type: 'table',
      headers: ['Metric', 'Q1', 'Q2', 'Q3', 'Q4'],
      data: [
        ['Revenue ($M)', '12.5', '15.3', '18.7', '22.1'],
        ['Customers', '1,250', '1,680', '2,100', '2,850'],
        ['Growth Rate', '12%', '15%', '18%', '21%'],
        ['Market Share', '8.2%', '9.1%', '10.5%', '12.3%']
      ],
      theme: 'grid',
      headerColor: [52, 73, 94],
      spacing: 15
    },
    {
      type: 'heading',
      text: 'Product Performance',
      level: 1
    },
    {
      type: 'paragraph',
      text: 'Our product portfolio has shown exceptional performance across all categories. The following highlights demonstrate our commitment to innovation and customer satisfaction.',
      fontSize: 12
    },
    {
      type: 'list',
      listType: 'bullet',
      items: [
        'Product A achieved 150% of sales target',
        'Product B expanded to 5 new markets',
        'Product C received industry recognition award',
        'New Product D launched successfully in Q4'
      ],
      fontSize: 11,
      spacing: 10
    },
    {
      type: 'heading',
      text: 'Customer Satisfaction',
      level: 1
    },
    {
      type: 'paragraph',
      text: 'Customer satisfaction remains our top priority. We conducted comprehensive surveys and gathered feedback throughout the year.',
      fontSize: 12
    },
    {
      type: 'table',
      headers: ['Category', 'Rating', 'Responses'],
      data: [
        ['Product Quality', '4.8/5.0', '2,450'],
        ['Customer Service', '4.7/5.0', '2,380'],
        ['Value for Money', '4.6/5.0', '2,410'],
        ['Overall Experience', '4.7/5.0', '2,500']
      ],
      theme: 'striped',
      spacing: 15
    },
    {
      type: 'heading',
      text: 'Future Outlook',
      level: 1
    },
    {
      type: 'paragraph',
      text: 'Looking ahead to 2025, we are optimistic about continued growth and expansion. Our strategic initiatives include:',
      fontSize: 12
    },
    {
      type: 'list',
      listType: 'number',
      items: [
        'Expansion into 3 new international markets',
        'Launch of 2 innovative product lines',
        'Investment in AI and automation technologies',
        'Enhanced customer support infrastructure'
      ],
      fontSize: 11,
      spacing: 10
    },
    {
      type: 'space',
      height: 15
    },
    {
      type: 'line',
      color: [200, 200, 200]
    },
    {
      type: 'paragraph',
      text: 'This report is confidential and intended for internal use only. For questions, contact: reports@company.com',
      fontSize: 9,
      align: 'center'
    }
  ];
const PDFGeneratorApp = () => {
  const [loading, setLoading] = useState(false);
  const [progress, setProgress] = useState(0);
  const [error, setError] = useState<string | null>(null);

  const handleGenerate = async (action: "preview" | "download") => {
    setLoading(true);
    setProgress(0);
    setError(null);

    try {
      const generator = new PDFGenerator();
      await generator.generate(sampleData, {
        addPageNumbers: true,
        onProgress: (prog: SetStateAction<number>) => setProgress(prog)
      });

      if (action === "preview") generator.preview();
      else generator.download("business-report-2024.pdf");

      setTimeout(() => {
        setLoading(false);
        setProgress(0);
      }, 500);
    } catch (err: any) {
      console.error("PDF Generation Error:", err);
      setError(err.message);
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 p-8">
      <div className="max-w-5xl mx-auto">
        <div className="bg-white rounded-lg shadow-2xl p-8">
          {/* Header */}
          <div className="flex items-center gap-4 mb-8">
            <div className="bg-indigo-600 p-3 rounded-lg">
              <FileText className="w-8 h-8 text-white" />
            </div>
            <div>
              <h1 className="text-3xl font-bold text-gray-800">PDF Generator Utility</h1>
              <p className="text-gray-600 mt-1">
                Generate PDFs with automatic page breaks • No split components
              </p>
            </div>
          </div>

          {/* Buttons */}
          <div className="flex gap-4 mb-8">
            <button
              onClick={() => handleGenerate("preview")}
              disabled={loading}
              className="flex items-center gap-2 bg-indigo-600 text-white px-6 py-3 rounded-lg hover:bg-indigo-700 transition disabled:opacity-50 font-medium shadow-lg"
            >
              {loading ? <Loader2 className="w-5 h-5 animate-spin" /> : <Eye className="w-5 h-5" />}
              Preview PDF
            </button>

            <button
              onClick={() => handleGenerate("download")}
              disabled={loading}
              className="flex items-center gap-2 bg-green-600 text-white px-6 py-3 rounded-lg hover:bg-green-700 transition disabled:opacity-50 font-medium shadow-lg"
            >
              <Download className="w-5 h-5" />
              Download PDF
            </button>
          </div>

          {/* Progress Bar */}
          {loading && (
            <div className="mb-8">
              <div className="flex justify-between items-center mb-2">
                <span className="text-sm font-medium text-gray-700">Generating PDF...</span>
                <span className="text-sm font-medium text-indigo-600">
                  {progress.toFixed(0)}%
                </span>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3 overflow-hidden">
                <div
                  className="bg-indigo-600 h-3 rounded-full transition-all duration-300"
                  style={{ width: `${progress}%` }}
                />
              </div>
            </div>
          )}

          {/* Error */}
          {error && (
            <div className="mb-6 bg-red-50 border border-red-200 rounded-lg p-4">
              <p className="text-red-800 font-medium">Error: {error}</p>
            </div>
          )}

          {/* Document info, usage examples ... same as before */}
        </div>
      </div>
    </div>
  );
};

export default PDFGeneratorApp;
