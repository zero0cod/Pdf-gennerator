
import './App.css'
import PDFGeneratorApp from './PDFPreviewGenerator'

function App() {

  return (
    <div className="App">
<PDFGeneratorApp />

      </div>
  )
}

export default App
